from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """
    Enhanced CRUD operations for the 'animals' collection in MongoDB.

    This version improves the original CS-340 artifact by adding stronger
    validation, improved error handling, and full CRUD functionality.
    """

    def __init__(self, username, password, host='localhost', port=27017, db='aac', collection='animals'):
        """
        Initialize the MongoDB connection using the provided credentials.
        """
        try:
            mongo_uri = f"mongodb://{username}:{password}@{host}:{port}"
            self.client = MongoClient(mongo_uri)
            self.database = self.client[db]
            self.collection = self.database[collection]

        except PyMongoError as e:
            print("Connection Error: Could not connect to MongoDB:", e)
            raise

    def create(self, data):
        """
        Insert a document into MongoDB.
        Returns True if the insert is successful and False otherwise.
        """
        if not data or not isinstance(data, dict):
            print("Create Error: Data must be a non-empty dictionary.")
            return False

        try:
            result = self.collection.insert_one(data)
            return result.inserted_id is not None

        except PyMongoError as e:
            print("Create Error:", e)
            return False

    def read(self, query=None, projection=None):
        """
        Read documents from MongoDB.
        Returns a list of matching documents.
        """
        if query is None or not isinstance(query, dict):
            query = {}

        if projection is not None and not isinstance(projection, dict):
            projection = None

        try:
            results = list(self.collection.find(query, projection))
            return results

        except PyMongoError as e:
            print("Read Error:", e)
            return []

    def update(self, query, new_values):
        """
        Update matching documents in MongoDB.
        Returns the number of modified documents.
        """
        if not query or not isinstance(query, dict):
            print("Update Error: Query must be a non-empty dictionary.")
            return 0

        if not new_values or not isinstance(new_values, dict):
            print("Update Error: New values must be a non-empty dictionary.")
            return 0

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count

        except PyMongoError as e:
            print("Update Error:", e)
            return 0

    def delete(self, query):
        """
        Delete matching documents from MongoDB.
        Returns the number of deleted documents.
        """
        if not query or not isinstance(query, dict):
            print("Delete Error: Query must be a non-empty dictionary.")
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count

        except PyMongoError as e:
            print("Delete Error:", e)
            return 0
