/*
 * ProjectTwo.cpp
 *
 * Original Project Created: Oct 25, 2025
 * Enhanced for CS-499 Capstone: May 2026
 * Author: Tania Boursiquot
 *
 * Enhancements:
 * - Duplicate course validation
 * - Missing data validation
 * - Prerequisite validation
 * - Search performance measurement
 * - Improved error handling
 *
 * Academic advising tool for CS300 Project Two.
 * Loads course data from a file, prints course list,
 * and prints info (title + prerequisites) for a single course.
 */
 
#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <cctype>
#include <chrono>

using namespace std;

struct Course {
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};

unordered_map<string, Course> courseTable;

string trim(const string& s);
string normalizeCourseNumber(const string& input);
void loadDataStructure(const string& filename);
void printCourseList();
void printCourseInfo(const string& courseNum);
void compareSearchPerformance();
void displayMenu();

string trim(const string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == string::npos) return "";

    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

string normalizeCourseNumber(const string& input) {
    string out = trim(input);

    for (char& c : out) {
        c = toupper(static_cast<unsigned char>(c));
    }

    return out;
}

void loadDataStructure(const string& filename) {
    courseTable.clear();

    ifstream file(filename);

    if (!file.is_open()) {
        cout << "Error: Could not open file \"" << filename << "\"." << endl << endl;
        return;
    }

    string line;
    int lineNumber = 0;
    int validCourses = 0;
    int skippedCourses = 0;

    while (getline(file, line)) {
        lineNumber++;

        if (trim(line).empty()) {
            continue;
        }

        vector<string> tokens;
        string token;
        stringstream ss(line);

        while (getline(ss, token, ',')) {
            tokens.push_back(trim(token));
        }

        if (tokens.size() < 2) {
            cout << "Warning: Line " << lineNumber
                 << " skipped because course number or title is missing." << endl;
            skippedCourses++;
            continue;
        }

        string courseNumber = normalizeCourseNumber(tokens[0]);
        string courseTitle = trim(tokens[1]);

        if (courseNumber.empty() || courseTitle.empty()) {
            cout << "Warning: Line " << lineNumber
                 << " skipped because course number or title is blank." << endl;
            skippedCourses++;
            continue;
        }

        if (courseTable.find(courseNumber) != courseTable.end()) {
            cout << "Warning: Duplicate course " << courseNumber
                 << " skipped." << endl;
            skippedCourses++;
            continue;
        }

        Course c;
        c.courseNumber = courseNumber;
        c.courseTitle = courseTitle;

        for (size_t i = 2; i < tokens.size(); ++i) {
            string prereq = normalizeCourseNumber(tokens[i]);

            if (!prereq.empty()) {
                c.prerequisites.push_back(prereq);
            }
        }

        courseTable[c.courseNumber] = c;
        validCourses++;
    }

    file.close();

    cout << "Data loaded successfully." << endl;
    cout << "Valid courses loaded: " << validCourses << endl;
    cout << "Skipped invalid or duplicate entries: " << skippedCourses << endl << endl;

    for (const auto& entry : courseTable) {
        for (const string& prereq : entry.second.prerequisites) {
            if (courseTable.find(prereq) == courseTable.end()) {
                cout << "Warning: Course " << entry.first
                     << " references missing prerequisite " << prereq << "." << endl;
            }
        }
    }

    cout << endl;
}

void printCourseList() {
    if (courseTable.empty()) {
        cout << "No course data available. Please load the data first." << endl << endl;
        return;
    }

    vector<string> keys;
    keys.reserve(courseTable.size());

    for (const auto& entry : courseTable) {
        keys.push_back(entry.first);
    }

    auto start = chrono::high_resolution_clock::now();

    sort(keys.begin(), keys.end());

    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);

    cout << "Here is a sample schedule:" << endl << endl;

    for (const string& courseNum : keys) {
        const Course& c = courseTable[courseNum];
        cout << c.courseNumber << ", " << c.courseTitle << endl;
    }

    cout << endl;
    cout << "Sorting completed in "
         << duration.count()
         << " microseconds." << endl << endl;
}

void printCourseInfo(const string& courseNumRaw) {
    if (courseTable.empty()) {
        cout << "No course data available. Please load the data first." << endl << endl;
        return;
    }

    string courseNum = normalizeCourseNumber(courseNumRaw);

    auto start = chrono::high_resolution_clock::now();

    auto it = courseTable.find(courseNum);

    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);

    if (it == courseTable.end()) {
        cout << "Course not found: " << courseNumRaw << endl;
        cout << "Search completed in "
             << duration.count()
             << " microseconds." << endl << endl;
        return;
    }

    const Course& c = it->second;

    cout << c.courseNumber << ", " << c.courseTitle << endl;

    cout << "Prerequisites: ";
    if (c.prerequisites.empty()) {
        cout << "None" << endl;
    } else {
        for (size_t i = 0; i < c.prerequisites.size(); ++i) {
            cout << c.prerequisites[i];

            if (i < c.prerequisites.size() - 1) {
                cout << ", ";
            }
        }

        cout << endl;
    }

    cout << "Search completed in "
         << duration.count()
         << " microseconds." << endl << endl;
}

void compareSearchPerformance() {
    if (courseTable.empty()) {
        cout << "Please load the data structure first." << endl << endl;
        return;
    }

    string courseNum;
    cout << "Enter course number to search: ";
    cin >> courseNum;

    courseNum = normalizeCourseNumber(courseNum);

    auto start = chrono::high_resolution_clock::now();

    auto it = courseTable.find(courseNum);

    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);

    if (it != courseTable.end()) {
        cout << "Course found: "
             << it->second.courseNumber
             << ", "
             << it->second.courseTitle
             << endl;
    } else {
        cout << "Course not found." << endl;
    }

    cout << "unordered_map search completed in "
         << duration.count()
         << " microseconds." << endl << endl;
}

void displayMenu() {
    cout << "Welcome to the course planner." << endl << endl;

    cout << "   1. Load Data Structure." << endl;
    cout << "   2. Print Course List." << endl;
    cout << "   3. Print Course." << endl;
    cout << "   4. Test Search Performance." << endl;
    cout << "   9. Exit" << endl << endl;
}

int main() {
    bool running = true;
    bool dataLoaded = false;

    while (running) {
        displayMenu();

        cout << "What would you like to do? ";
        string choice;
        cin >> choice;
        cout << endl;

        if (choice == "1") {
            string filename;

            cout << "Enter the filename to load: ";
            cin >> filename;
            cout << endl;

            loadDataStructure(filename);

            if (!courseTable.empty()) {
                dataLoaded = true;
            }

        } else if (choice == "2") {
            if (!dataLoaded) {
                cout << "Please load the data structure first (option 1)." << endl << endl;
            } else {
                printCourseList();
            }

        } else if (choice == "3") {
            if (!dataLoaded) {
                cout << "Please load the data structure first (option 1)." << endl << endl;
            } else {
                cout << "What course do you want to know about? ";
                string courseQuery;
                cin >> courseQuery;
                cout << endl;

                printCourseInfo(courseQuery);
            }

        } else if (choice == "4") {
            compareSearchPerformance();

        } else if (choice == "9") {
            cout << "Thank you for using the course planner!" << endl;
            running = false;

        } else {
            cout << choice << " is not a valid option." << endl << endl;
        }
    }

    return 0;
}